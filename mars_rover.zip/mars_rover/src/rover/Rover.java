package rover;

import grid.Grid;

public class Rover {
    private int x;
    private int y;
    private String direction;
    public final Grid grid;

    public Rover(int x, int y, String direction, Grid grid) {
        this.x = x;
        this.y = y;
        this.direction = direction;
        this.grid = grid;
    }

    public void moveForward() {
        int nextX = x;
        int nextY = y;

        switch (direction) {
            case "N":
                nextY += 1;
                break;
            case "S":
                nextY -= 1;
                break;
            case "E":
                nextX += 1;
                break;
            case "W":
                nextX -= 1;
                break;
        }

        if (nextX >= 0 && nextX < grid.getWidth() && nextY >= 0 && nextY < grid.getHeight()) {
            x = nextX;
            y = nextY;
        }
    }

    public void turnLeft() {
        switch (direction) {
            case "N": direction = "W"; break;
            case "W": direction = "S"; break;
            case "S": direction = "E"; break;
            case "E": direction = "N"; break;
        }
    }

    public void turnRight() {
        switch (direction) {
            case "N": direction = "E"; break;
            case "E": direction = "S"; break;
            case "S": direction = "W"; break;
            case "W": direction = "N"; break;
        }
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public String getDirection() {
        return direction;
    }

    public int getNextX() {
        switch (direction) {
            case "N": return x;
            case "S": return x;
            case "E": return x + 1;
            case "W": return x - 1;
            default: return x;
        }
    }

    public int getNextY() {
        switch (direction) {
            case "N": return y + 1;
            case "S": return y - 1;
            case "E": return y;
            case "W": return y;
            default: return y;
        }
    }

    public void avoidObstacle() {
        // Logic to move around the obstacle (simple logic for now)
        switch (direction) {
            case "N": turnRight(); break; // Just turn right to avoid
            case "S": turnLeft(); break; // Just turn left to avoid
            case "E": turnLeft(); break; // Just turn left to avoid
            case "W": turnRight(); break; // Just turn right to avoid
        }
        moveForward(); // Move after avoiding
    }
}
