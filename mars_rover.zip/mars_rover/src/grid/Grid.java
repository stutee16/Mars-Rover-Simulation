package grid;

import java.util.HashSet;
import java.util.Set;

public class Grid {
    private final int width;
    private final int height;
    private final Set<String> obstacles;

    public Grid(int width, int height, String[] obstacles) {
        this.width = width;
        this.height = height;
        this.obstacles = new HashSet<>();
        for (String obstacle : obstacles) {
            this.obstacles.add(obstacle);
        }
    }

    public boolean isObstacle(int x, int y) {
        return obstacles.contains(x + "," + y);
    }

    public int getWidth() {
        return width;
    }

    public int getHeight() {
        return height;
    }
}
