package commands;

public interface Command {
    boolean execute(); // Returns true if command executed successfully
}
