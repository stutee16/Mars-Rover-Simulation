package commands;

import rover.Rover;

public class TurnRightCommand implements Command {
    private final Rover rover;

    public TurnRightCommand(Rover rover) {
        this.rover = rover;
    }

    @Override
    public boolean execute() {
        rover.turnRight();
        return true; // Always succeeds
    }
}
