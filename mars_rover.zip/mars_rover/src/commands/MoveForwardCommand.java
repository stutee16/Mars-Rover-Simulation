package commands;

import rover.Rover;

public class MoveForwardCommand implements Command {
    private final Rover rover;

    public MoveForwardCommand(Rover rover) {
        this.rover = rover;
    }

    @Override
    public boolean execute() {
        int nextX = rover.getNextX();
        int nextY = rover.getNextY();
        
        // Check if the next position is an obstacle
        if (rover.grid.isObstacle(nextX, nextY)) {
            return false; // Move failed due to obstacle
        }

        rover.moveForward(); // Move the rover if no obstacle
        return true; // Move executed successfully
    }
}
