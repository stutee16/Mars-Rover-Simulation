package mars_rover;

import commands.Command;
import commands.MoveForwardCommand;
import commands.TurnLeftCommand;
import commands.TurnRightCommand;
import grid.Grid;
import rover.Rover;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Getting grid dimensions and rover's initial position from user
        System.out.print("Enter grid width: ");
        int width = scanner.nextInt();
        System.out.print("Enter grid height: ");
        int height = scanner.nextInt();
        System.out.print("Enter Rover's starting X position: ");
        int startX = scanner.nextInt();
        System.out.print("Enter Rover's starting Y position: ");
        int startY = scanner.nextInt();
        System.out.print("Enter Rover's starting direction (N, S, E, W): ");
        String direction = scanner.next().toUpperCase();

        // Create a grid and a rover
        String[] obstacles = {"2,2", "1,3"}; // Predefined obstacles in the format "x,y"
        Grid grid = new Grid(width, height, obstacles);
        Rover rover = new Rover(startX, startY, direction, grid);

        // Process commands from the user
        System.out.print("Enter commands (e.g., MMLMRM): ");
        String commands = scanner.next().toUpperCase();

        // Execute each command
        for (char command : commands.toCharArray()) {
            switch (command) {
                case 'M':
                    // Move the rover
                    MoveForwardCommand moveCommand = new MoveForwardCommand(rover);
                    if (moveCommand.execute()) {
                        System.out.println("Moved to (" + rover.getX() + ", " + rover.getY() + ") facing " + rover.getDirection());
                    } else {
                        // If moving results in hitting an obstacle, ask for user input
                        System.out.print("Obstacle detected at (" + rover.getNextX() + ", " + rover.getNextY() + ")! Do you want to continue in this direction? (Y/N): ");
                        char decision = scanner.next().toUpperCase().charAt(0);
                        if (decision == 'Y') {
                            rover.avoidObstacle(); // Method to avoid obstacle
                        } else {
                            System.out.println("Stopped at (" + rover.getX() + ", " + rover.getY() + ") facing " + rover.getDirection());
                            break; // Stop further commands
                        }
                    }
                    break;
                case 'L':
                    new TurnLeftCommand(rover).execute();
                    System.out.println("Turned left. Now facing " + rover.getDirection());
                    break;
                case 'R':
                    new TurnRightCommand(rover).execute();
                    System.out.println("Turned right. Now facing " + rover.getDirection());
                    break;
                default:
                    System.out.println("Invalid command. Use M (move), L (turn left), R (turn right).");
                    break;
            }
        }
        // Final position of the rover
        System.out.println("Rover is at (" + rover.getX() + ", " + rover.getY() + ") facing " + rover.getDirection() + ".");
        if (!grid.isObstacle(rover.getX(), rover.getY())) {
            System.out.println("No obstacles detected in the current position.");
        }

        scanner.close(); // Close scanner
    }
}
